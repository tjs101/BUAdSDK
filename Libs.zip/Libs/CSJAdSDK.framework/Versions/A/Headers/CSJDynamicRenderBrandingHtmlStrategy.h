//
//  CSJDynamicRenderBrandingHtmlStrategy.h
//  CSJAdSDK
//
//  Created by bytedance on 2022/2/22.
//

#import "CSJRenderStrategy.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSJDynamicRenderBrandingHtmlStrategy : CSJRenderStrategy

@end

NS_ASSUME_NONNULL_END
