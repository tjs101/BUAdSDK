//
//  CSJRewardedVideoAd+Private.h
//  CSJAdSDK
//
//  Created by wangyanlin on 2021/5/30.
//

#import <CSJAdSDK/CSJAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSJRewardedVideoAd ()
@property (nonatomic, strong) CSJAdSlot *slot;
@end

NS_ASSUME_NONNULL_END
