//
//  CSJProgressLoadingPageView.h
//  loadingPageTest
//
//  Created by bytedance on 2021/11/1.
//

#import "CSJBaseLoadingPageView.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSJProgressLoadingPageView : CSJBaseLoadingPageView

@end

NS_ASSUME_NONNULL_END
