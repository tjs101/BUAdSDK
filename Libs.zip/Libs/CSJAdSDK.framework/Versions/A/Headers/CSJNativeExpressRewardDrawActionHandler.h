//
//  CSJNativeExpressRewardDrawActionHandler.h
//  CSJAdSDK
//
//  Created by ByteDance on 2022/7/26.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "CSJNativeExpressRewardedVideoAdViewController.h"
#import "CSJNativeExpressRewardDrawDisplayViewController.h"
#import "CSJNativeExpressRewardDrawAdView.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSJNativeExpressRewardDrawActionHandler : NSObject

+ (void)dismissCurrentViewControllerIsSkip:(BOOL)isSkip
                                    rootVC:(UIViewController *)rootVC
                           rewardedVideoAd:(id<CSJNativeExpressVideoAdDelegate>)rewardedVideoAd
                                  animated:(BOOL)animated;

@end

NS_ASSUME_NONNULL_END
