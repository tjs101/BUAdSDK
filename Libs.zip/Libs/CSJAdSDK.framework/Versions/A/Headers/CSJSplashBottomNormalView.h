//
//  CSJSplashBottomNormalView.h
//  CSJAdSDK
//
//  Created by bytedance on 2021/9/15.
//

#import "CSJSplashBottomBaseComponentView.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSJSplashBottomNormalView : CSJSplashBottomBaseComponentView

@end

NS_ASSUME_NONNULL_END
