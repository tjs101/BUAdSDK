//
//  CSJSplashBottomZoomAnimationView.h
//  CSJAdSDK
//
//  Created by bytedance on 2021/9/15.
//

#import <UIKit/UIKit.h>
#import "CSJSplashBottomBaseComponentView.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSJSplashBottomZoomAnimationView : CSJSplashBottomBaseComponentView

@end

NS_ASSUME_NONNULL_END
