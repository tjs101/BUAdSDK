//
//  CSJRewardDrawAdPlayerManager.h
//  CSJAdSDK
//
//  Created by ByteDance on 2022/8/4.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

// thread not safe
@interface CSJRewardDrawAdPlayerManager : NSObject

+ (instancetype)sharedInstance;

- (BUPlayer *)playerWithPlayerItem:(BUPlayerItem *)item;

- (void)releasePlayer:(BUPlayer *)player;

- (void)deallocAllPlayers;

@end

NS_ASSUME_NONNULL_END
