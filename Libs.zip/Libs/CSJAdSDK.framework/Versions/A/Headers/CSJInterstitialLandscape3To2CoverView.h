//
//  CSJInterstitialLandscape3To2CoverView.h
//  CSJAdSDK
//
//  Created by bytedance on 2021/2/12.
//

#import "CSJInterstitialCoverView.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSJInterstitialLandscape3To2CoverView : CSJInterstitialCoverView

@end

NS_ASSUME_NONNULL_END
