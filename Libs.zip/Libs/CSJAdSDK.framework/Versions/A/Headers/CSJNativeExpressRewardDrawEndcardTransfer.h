//
//  CSJNativeExpressRewardDrawEndcardTransfer.h
//  CSJAdSDK
//
//  Created by ByteDance on 2022/7/29.
//

#import <Foundation/Foundation.h>
#import "CSJNativeExpressRewardDrawAdView.h"
#import "CSJNativeExpressVideoAdDelegate.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSJNativeExpressRewardDrawEndcardTransfer : NSObject

@property (nonatomic, weak) id<CSJNativeExpressVideoAdDelegate> rewardedVideoAd;
@property (nonatomic, weak) CSJNativeExpressRewardDrawAdView *drawAdView;

- (instancetype)initWithSlot:(CSJAdSlot *)slot materialMeta:(CSJMaterialMeta *)materialMeta;

- (void)switchToEndcardWithRootVC:(UIViewController *)rootVC fromVC:(UIViewController *)fromVC isMute:(BOOL)isMute;

@end

NS_ASSUME_NONNULL_END
