//
//  CSJInterstitialPortrait9To16CoverView.h
//  CSJAdSDK
//
//  Created by bytedance on 2021/2/10.
//

#import "CSJInterstitialCoverView.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSJInterstitialPortrait9To16CoverView : CSJInterstitialCoverView

@end

NS_ASSUME_NONNULL_END
