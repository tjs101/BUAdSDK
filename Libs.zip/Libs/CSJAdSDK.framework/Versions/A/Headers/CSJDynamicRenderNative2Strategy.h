//
//  CSJDynamicRenderNative2Strategy.h
//  CSJAdSDK
//
//  Created by Rush.D.Xzj on 2021/7/12.
//

#import "CSJDynamicRenderNativeStrategy.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSJDynamicRenderNative2Strategy : CSJDynamicRenderNativeStrategy

@end

NS_ASSUME_NONNULL_END
