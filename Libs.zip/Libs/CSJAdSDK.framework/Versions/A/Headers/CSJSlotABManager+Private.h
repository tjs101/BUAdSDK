//
//  CSJSlotABManager+Private.h
//  CSJAdSDK
//
//  Created by shenqichen on 2021/11/8.
//

#import "CSJSlotABManager.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSJSlotABManager ()

- (NSString*)dynamicSlotABExtraWithID:(NSString*)slotID;

@end

NS_ASSUME_NONNULL_END
