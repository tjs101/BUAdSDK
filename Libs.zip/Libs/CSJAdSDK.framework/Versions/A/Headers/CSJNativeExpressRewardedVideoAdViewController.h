//
//  CSJNativeExpressRewardedVideoAdViewController.h
//  CSJAdSDK
//
//  Created by cuiyanan on 2019/8/7.
//  Copyright © 2019 bytedance. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CSJNativeExpressVideoAdDelegate.h"

@class CSJNativeExpressRewardedVideoAdView;
@class CSJNativeAd;
@class CSJAdSlot;
@class CSJDislikeContext;
@class CSJExpressRewardFullScreenVM;

NS_ASSUME_NONNULL_BEGIN

@interface CSJNativeExpressRewardedVideoAdViewController : UIViewController
@property (nonatomic, weak) id<CSJNativeExpressVideoAdDelegate> rewardedVideoAd;
@property (nonatomic, assign) BOOL isRewardedVideo;
@property (nonatomic, strong) CSJAdSlot *adSlot;
@property (nonatomic, copy) dispatch_block_t purePlayableClickBlock;
@property (nonatomic, strong) CSJExpressRewardFullScreenVM *viewModel;


- (instancetype)initWithNativeExpressAdView:(CSJNativeExpressRewardedVideoAdView *)expressAdView purePlayableNativeAd:(CSJNativeAd *)purePlayableNativeAd;

@end

NS_ASSUME_NONNULL_END
