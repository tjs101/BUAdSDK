//
//  BU_Gecko.h
//  Pods
//
//  Created by zth on 2022/5/27.
//

#ifndef BU_Gecko_h
#define BU_Gecko_h

#import "BUGeckoPreloadManager.h"


#endif /* BU_Gecko_h */
