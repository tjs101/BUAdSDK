//
//  CSJDislikeButton.h
//  CSJAdSDK
//
//  Created by gdp on 2018/1/21.
//  Copyright © 2018年 bytedance. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CSJDislikeButton : UIButton

@end
