//
//  CSJFullScreenSplashCoverView.h
//  CSJAdSDK
//
//  Created by Rush.D.Xzj on 2021/3/29.
//

#import "CSJSplashCoverView.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSJFullScreenSplashCoverView : CSJSplashCoverView

@end

NS_ASSUME_NONNULL_END
