//
//  CSJBigBannerOverseaCoverView.h
//  CSJAdSDK
//
//  Created by Rush.D.Xzj on 2020/9/25.
//  Copyright © 2020 bytedance. All rights reserved.
//

#import "CSJBannerOverseaCoverView.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSJBigBannerOverseaCoverView : CSJBannerOverseaCoverView

@end

NS_ASSUME_NONNULL_END
