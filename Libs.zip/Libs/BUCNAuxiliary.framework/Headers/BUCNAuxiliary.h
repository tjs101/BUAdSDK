//
//  BUCNAuxiliary.h
//  BUCNAuxiliary
//
//  Created by bytedance on 2020/8/25.
//  Copyright © 2020 bytedance. All rights reserved.
//

#import <Foundation/Foundation.h>

///
#import "BUCNAuxiliaryManager.h"

//! Project version number for BUCNAuxiliary.
FOUNDATION_EXPORT double BUCNAuxiliaryVersionNumber;

//! Project version string for BUCNAuxiliary.
FOUNDATION_EXPORT const unsigned char BUCNAuxiliaryVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BUCNAuxiliary/PublicHeader.h>


