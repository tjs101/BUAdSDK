//
//  CSJInterstitialLandscape9To16CoverView.h
//  CSJAdSDK
//
//  Created by bytedance on 2021/2/12.
//

#import "CSJInterstitialCoverView.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSJInterstitialLandscape9To16CoverView : CSJInterstitialCoverView

@end

NS_ASSUME_NONNULL_END
