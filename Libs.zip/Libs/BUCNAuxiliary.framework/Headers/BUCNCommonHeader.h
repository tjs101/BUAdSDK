//
//  BUCNCommonHeader.h
//  BUCNAuxiliary
//
//  Created by bytedance on 2020/8/27.
//  Copyright © 2020 bytedance. All rights reserved.
//

#ifndef BUCNCommonHeader_h
#define BUCNCommonHeader_h

typedef NS_ENUM(NSUInteger, BUCNAuxiliaryTerritory) {
    BUCNAuxiliaryTerritory_CN = 3,
};

#endif /* BUCNCommonHeader_h */
