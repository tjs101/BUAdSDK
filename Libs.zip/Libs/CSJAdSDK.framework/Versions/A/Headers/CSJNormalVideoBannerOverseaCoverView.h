//
//  CSJNormalVideoBannerOverseaCoverView.h
//  CSJAdSDK
//
//  Created by Rush.D.Xzj on 2020/9/25.
//  Copyright © 2020 bytedance. All rights reserved.
//

#import "CSJVideoBannerOverseaCoverView.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSJNormalVideoBannerOverseaCoverView : CSJVideoBannerOverseaCoverView

@end

NS_ASSUME_NONNULL_END
