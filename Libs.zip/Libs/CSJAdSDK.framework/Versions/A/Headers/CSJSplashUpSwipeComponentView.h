//
//  BUSplashBottomUpSwipeAnimationMask.h
//  CSJAdSDK
//
//  Created by Willie on 2021/9/16.
//

#import "CSJSplashBottomBaseComponentView.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSJSplashUpSwipeComponentView : CSJSplashBottomBaseComponentView


- (void)updateFrameIfNeed;

@end

NS_ASSUME_NONNULL_END
