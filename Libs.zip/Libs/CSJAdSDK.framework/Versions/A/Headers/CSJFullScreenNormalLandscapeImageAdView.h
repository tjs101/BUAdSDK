//
//  CSJFullScreenNormalLandscapeImageAdView.h
//  CSJAdSDK
//
//  Created by bytedance on 2021/1/9.
//

#import "CSJFullScreenInterstitialAdView.h"

NS_ASSUME_NONNULL_BEGIN

/// image_model = 3, 1.91 : 1 横屏
/// BUFullScreenImageStyleNormalLandscape
@interface CSJFullScreenNormalLandscapeImageAdView : CSJFullScreenInterstitialAdView

@end

NS_ASSUME_NONNULL_END
