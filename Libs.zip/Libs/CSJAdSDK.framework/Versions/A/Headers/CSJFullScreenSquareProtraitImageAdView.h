//
//  CSJFullScreenSquareProtraitImageAdView.h
//  CSJAdSDK
//
//  Created by bytedance on 2021/1/9.
//

#import "CSJFullScreenInterstitialAdView.h"

NS_ASSUME_NONNULL_BEGIN

/// image_model = 33, 方图 竖屏
/// BUFullScreenImageStyleSquarePortrait
@interface CSJFullScreenSquareProtraitImageAdView : CSJFullScreenInterstitialAdView

@end

NS_ASSUME_NONNULL_END
