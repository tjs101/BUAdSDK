//
//  CSJNativeExpressRewardDrawAdView.h
//  CSJAdSDK
//
//  Created by ByteDance on 2022/7/28.
//

#import <CSJAdSDK/CSJAdSDK.h>
#import "CSJNativeExpressAdView.h"
#import "CSJNativeExpressAdView+Interval.h"

NS_ASSUME_NONNULL_BEGIN

@class BUPlayer;
@class CSJDislikeContext;
@class CSJNativeExpressRewardDrawAdView;
@protocol CSJRewardedVideoDrawAdViewDelegate <NSObject>

- (void)rewardDrawAdViewSwitchToEndcard:(CSJNativeExpressRewardDrawAdView *)reardDrawAdView;

- (void)rewardDrawAdViewDimissCurrentVC:(CSJNativeExpressRewardDrawAdView *)rewardDrawAdView;

- (void)rewardDrawAdViewDidPlayFinish:(CSJNativeExpressRewardDrawAdView *)rewardDrawAdView player:(BUPlayer *)player error:(NSError *_Nullable)error;

- (NSUInteger)rewardDrawAdViewGetRewardLeftTime;

- (void)rewardDrawAdViewIsShowAlert:(BOOL)isShowAlert adView:(CSJNativeExpressRewardDrawAdView *)rewardDrawAdView;

@end

@interface CSJNativeExpressRewardDrawAdView : CSJNativeExpressAdView

@property (nonatomic, weak) id <CSJRewardedVideoDrawAdViewDelegate> delegate;

@property (nonatomic, strong) CSJDislikeContext *dislikeContext;
@property (nonatomic, assign, readonly) BOOL didReachMaxContrubuteValue;
@property (nonatomic, copy, readonly) NSArray *relatedMaterialMetas; // 相关推荐物料
@property (nonatomic, copy, readonly) NSDictionary *relatedMaterialMetasJson; // 相关推荐物料或者鲁班聚合页引流广告

- (instancetype)initWithFrame:(CGRect)frame nativeAd:(nonnull CSJNativeAd *)nativeAd nativeExpressAdViewSource:(BUNativeExpressAdViewSource)nativeExpressAdViewSource;

- (void)increaseContributeValue;

- (void)handleSkipVideo;

- (void)showDislikeHUD;

- (void)viewDidDisappear;

- (void)viewWillAppear;

@end

NS_ASSUME_NONNULL_END
