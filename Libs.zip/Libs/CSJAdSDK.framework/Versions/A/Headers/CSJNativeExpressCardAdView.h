//
//  CSJNativeExpressCardAdView.h
//  CSJAdSDK
//
//  Created by yujie on 2022/6/14.
//

#import <UIKit/UIKit.h>
#import "CSJNativeExpressAdView.h"
NS_ASSUME_NONNULL_BEGIN

@interface CSJNativeExpressCardAdView : CSJNativeExpressAdView

@property (nonatomic, weak) id<CSJNativeExpressAdViewDelegate> delegate;
@property (nonatomic, weak) CSJNativeExpressAdManager *expressAdManager;
/// 初始化1.5卡样式
/// @param rect 位置
/// @param views expressAdViews
/// @param slot AdSlot
- (instancetype)initWithFrame:(CGRect)rect
                   expressAds:(NSArray *)views
                         slot:(CSJAdSlot *)slot;
@end

NS_ASSUME_NONNULL_END
