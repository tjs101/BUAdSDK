//
//  CSJScaleLoadingPageView.h
//  loadingPageTest
//
//  Created by bytedance on 2021/11/2.
//

#import "CSJBaseLoadingPageView.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSJScaleLoadingPageView : CSJBaseLoadingPageView

@end

NS_ASSUME_NONNULL_END
