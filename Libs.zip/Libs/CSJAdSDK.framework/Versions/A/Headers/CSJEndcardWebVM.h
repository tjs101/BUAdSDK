//
//  BUEndcardWebVCVM.h
//  CSJAdSDK
//
//  Created by shenqichen on 2021/12/16.
//

#import "CSJRewardedVideoWebViewControllerVM.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSJEndcardWebVM : CSJRewardedVideoWebViewControllerVM

@end

NS_ASSUME_NONNULL_END
