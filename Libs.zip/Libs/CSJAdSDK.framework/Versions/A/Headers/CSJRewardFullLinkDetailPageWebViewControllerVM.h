//
//  CSJRewardFullLinkDetailPageWebViewControllerVM.h
//  CSJAdSDK
//
//  Created by ByteDance on 2022/9/2.
//

#import <CSJAdSDK/CSJAdSDK.h>
#import "CSJWebViewControllerViewModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSJRewardFullLinkDetailPageWebViewControllerVM : CSJWebViewControllerViewModel

@end

NS_ASSUME_NONNULL_END
