//
//  CSJNativeExpressVideoView.h
//  CSJAdSDK
//
//  Created by bytedance on 2020/8/4.
//  Copyright © 2020 bytedance. All rights reserved.
//

#import "CSJNativeExpressAdView.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSJNativeExpressVideoView : CSJNativeExpressAdView

@end

NS_ASSUME_NONNULL_END
