//
//  CSJNativeExpressRewardDrawProgressView.h
//  CSJAdSDK
//
//  Created by ByteDance on 2022/8/1.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

// 66 * 78
@interface CSJNativeExpressRewardDrawProgressView : UIView

@property (nonatomic, assign) NSUInteger totalTime;
@property (nonatomic, strong) UIImageView *tipsView;

- (void)updateCountDown:(NSUInteger)countDown;

- (void)refreshWhenRewardDidSend;

@end

NS_ASSUME_NONNULL_END
