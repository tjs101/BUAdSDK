//
//  CSJSmallBannerCoverView.h
//  CSJAdSDK
//
//  Created by Rush.D.Xzj on 2020/9/20.
//  Copyright © 2020 bytedance. All rights reserved.
//

#import "CSJBannerCoverView.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSJSmallBannerCoverView : CSJBannerCoverView

@end

NS_ASSUME_NONNULL_END
