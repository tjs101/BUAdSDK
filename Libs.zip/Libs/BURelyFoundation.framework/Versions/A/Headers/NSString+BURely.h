//
//  NSString+BURely.h
//  BUFoundation
//
//  Created by zth on 2021/12/25.
//



NS_ASSUME_NONNULL_BEGIN

@interface NSString (BURely)


+ (nullable NSURL *)BU_Rely_URLWithURLString:(NSString *)str;

@end

NS_ASSUME_NONNULL_END
