//
//  CSJRewardedVideoAgianAd.h
//  CSJAdSDK
//
//  Created by wangyanlin on 2021/5/30.
//

#import <Foundation/Foundation.h>
#import "CSJRewardedVideoAgianDelegate.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSJRewardedVideoAgianAd : NSObject<CSJRewardedVideoAgianDelegate>

@end

NS_ASSUME_NONNULL_END
