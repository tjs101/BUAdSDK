//
//  CSJSplashUpSwipe3dComponentView.h
//  CSJAdSDK
//
//  Created by Rush.D.Xzj on 2022/9/8.
//

#import "CSJSplashBottomBaseComponentView.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSJSplashUpSwipe3dComponentView : CSJSplashBottomBaseComponentView

@end

NS_ASSUME_NONNULL_END
