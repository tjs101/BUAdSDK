//
//  CSJNativeExpressFeedVideoAdView.h
//  CSJAdSDK
//
//  Created by cuiyanan on 2019/8/6.
//  Copyright © 2019 bytedance. All rights reserved.
//

#import "CSJNativeExpressAdView.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSJNativeExpressFeedVideoAdView : CSJNativeExpressAdView
@end

NS_ASSUME_NONNULL_END
