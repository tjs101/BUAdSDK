//
//  CSJRewardedVideoWebMaskView.h
//  CSJAdSDK
//
//  Created by Levi on 1/12/21.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSJRewardedVideoWebMaskView : UIView

@property (nonatomic, strong) UIImageView *iconImageView;

@end

NS_ASSUME_NONNULL_END
