//
//  CSJVerticalInterstitialCoverView.h
//  CSJAdSDK
//
//  Created by Rush.D.Xzj on 2020/9/20.
//  Copyright © 2020 bytedance. All rights reserved.
//

#import "CSJInterstitialCoverView.h"

NS_ASSUME_NONNULL_BEGIN

// 这里内部需要区分长方形和正方形样式
@interface CSJVerticalInterstitialCoverView : CSJInterstitialCoverView

@end

NS_ASSUME_NONNULL_END
