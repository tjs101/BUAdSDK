//
//  CSJNativeExpressVideoAdDelegate.h
//  Pods
//
//  Created by ByteDance on 2022/8/4.
//

#ifndef CSJNativeExpressVideoAdDelegate_h
#define CSJNativeExpressVideoAdDelegate_h

@protocol CSJNativeExpressVideoAdDelegate <NSObject>
@optional
- (void)nativeExpressVideoAdDidPlayFinishWithError:(nullable NSError *)error;
- (void)nativeExpressVideoAdDidClickSkip;
- (void)nativeExpressVideoAdEndcardWillClose;
- (void)nativeExpressVideoAdEndcardDidClose;
/// native express video ad reward verify: include C2C and S2S methods .
- (void)nativeExpressVideoAdServerRewardDidSucceedVerify:(BOOL)verify;
- (void)nativeExpressVideoAdServerRewardDidFailWithError:(nullable NSError *)error;
@end


#endif /* CSJNativeExpressVideoAdDelegate_h */
