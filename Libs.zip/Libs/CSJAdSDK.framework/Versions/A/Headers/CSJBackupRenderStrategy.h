//
//  CSJBackupRenderStrategy.h
//  CSJAdSDK
//
//  Created by Rush.D.Xzj on 2021/2/3.
//

#import <Foundation/Foundation.h>
#import "CSJRenderStrategy.h"

NS_ASSUME_NONNULL_BEGIN

@class CSJBackupRenderStrategy;


// 兜底渲染
@interface CSJBackupRenderStrategy : CSJRenderStrategy


@end

NS_ASSUME_NONNULL_END
