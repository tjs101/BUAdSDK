//
//  CSJPlayableLoadingAppInfoCell.h
//  CSJAdSDK
//
//  Created by yujie on 2022/2/14.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSJPlayableLoadingAppInfoCell : UIView
@property (nonatomic, strong) UILabel *content;
@property (nonatomic, strong) UILabel *title;
@end

NS_ASSUME_NONNULL_END
