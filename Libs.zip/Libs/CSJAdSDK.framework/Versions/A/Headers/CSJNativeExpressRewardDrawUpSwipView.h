//
//  CSJNativeExpressRewardDrawUpSwipView.h
//  CSJAdSDK
//
//  Created by ByteDance on 2022/8/9.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSJNativeExpressRewardDrawUpSwipView : UIView

- (void)startAnimation;

@end

NS_ASSUME_NONNULL_END
