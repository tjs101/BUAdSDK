//
//  CSJPlayableVM.h
//  CSJAdSDK
//
//  Created by wangyanlin on 2020/8/13.
//  Copyright © 2020 bytedance. All rights reserved.
//

#import "CSJRewardFullScreenBaseVM.h"

NS_ASSUME_NONNULL_BEGIN

// 纯playable的vm
@interface CSJPlayableVM : CSJRewardFullScreenBaseVM

@end

NS_ASSUME_NONNULL_END
