//
// Created by bytedance on 2020/12/16.
//

#import <Foundation/Foundation.h>
#import "BUCommonMacros.h"

@interface BUTNCRequestParam : NSObject <BUDictionarify>

@property (nonatomic, copy) NSString *version;

@property (nonatomic, copy) NSString *deviceDid;

@property (nonatomic, copy) NSString *ssAppID;

/// 新增字段，TNC请求频控用，不会带到真实的请求参数里
/// 时间间隔，单位：s
@property (nonatomic, assign) NSInteger interval;

@end
