//
//  CSJDynamicRenderNative1Strategy.h
//  CSJAdSDK
//
//  Created by Rush.D.Xzj on 2021/7/12.
//

#import "CSJDynamicRenderNativeStrategy.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSJDynamicRenderNative1Strategy : CSJDynamicRenderNativeStrategy

@end

NS_ASSUME_NONNULL_END
