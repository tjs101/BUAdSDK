//
//  CSJExpressEndcardViewModel.h
//  CSJAdSDK
//
//  Created by wangyanlin on 2020/8/16.
//  Copyright © 2020 bytedance. All rights reserved.
//

#import "CSJExpressRewardFullScreenVM.h"

NS_ASSUME_NONNULL_BEGIN

typedef void(^RelatedMaterialMetaBlock)(NSArray *materialMetas, NSDictionary *materialMetasJson);

@interface CSJExpressEndcardViewModel : CSJExpressRewardFullScreenVM

+ (void)getMRelatedMaterialMetaWithSlot:(CSJAdSlot *)slot materialMeta:(CSJMaterialMeta *)data resultBlock:(RelatedMaterialMetaBlock)block;

@end

NS_ASSUME_NONNULL_END
