//
//  CSJRewardedVideoConstants.h
//  Pods
//
//  Created by ByteDance on 2022/7/27.
//

#ifndef CSJRewardedVideoConstants_h
#define CSJRewardedVideoConstants_h

typedef NS_ENUM(NSUInteger, RewardedVideoQuitReason) {
    RewardedVideoQuitReason_URLError,
    RewardedVideoQuitReason_FirstRenderTimeOut,
    RewardedVideoQuitReason_BufferTimeOut,
    RewardedVideoQuitReason_PlayerError,
    RewardedVideoQuitReason_SkipButtonClick,
    RewardedVideoQuitReason_PlayFinish,
    RewardedVideoQuitReason_ApplicationWillTerminate,
};

#endif /* CSJRewardedVideoConstants_h */
