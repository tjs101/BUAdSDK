//
//  CSJNativeExpressRewardDrawDisplayViewController.h
//  CSJAdSDK
//
//  Created by ByteDance on 2022/7/25.
//

#import <UIKit/UIKit.h>
#import "CSJNativeExpressVideoAdDelegate.h"

NS_ASSUME_NONNULL_BEGIN

@class CSJNativeExpressRewardDrawAdView;
@interface CSJNativeExpressRewardDrawDisplayViewController : UIViewController

@property (nonatomic, weak, nullable) id<CSJNativeExpressVideoAdDelegate> rewardedVideoAd;

- (instancetype)initWithExpressAdViews:(NSArray <CSJNativeExpressRewardDrawAdView *> *)expressAdViews parentVC:(UIViewController *)parentVC slot:(nonnull CSJAdSlot *)slot;

@end

NS_ASSUME_NONNULL_END
