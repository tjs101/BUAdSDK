//
//  CSJNativeExpressRewardDrawRewardSender.h
//  CSJAdSDK
//
//  Created by ByteDance on 2022/8/1.
//

#import <Foundation/Foundation.h>
#import "CSJRewardedVideoModel.h"
#import "CSJNativeExpressVideoAdDelegate.h"

NS_ASSUME_NONNULL_BEGIN


typedef void(^RewardSendResultBlock)(BOOL isSuccess, BOOL isVerify);

@class CSJURitSettingModel, CSJMaterialMeta;
@interface CSJNativeExpressRewardDrawRewardSender : NSObject

- (instancetype)initWithRewardedVideoAd:(id<CSJNativeExpressVideoAdDelegate>)rewardedVideoAd;

- (void)sendVerifiedRewardWithDuration:(NSTimeInterval)durationTime
                                  type:(BURewardType)rewardType
                                  meta:(CSJMaterialMeta *)meta
                          settingModel:(CSJURitSettingModel *)ritSettingModel
                           playStartTS:(NSString *)playStartTS
                           resultBlock:(RewardSendResultBlock)resultBlock;

@end

NS_ASSUME_NONNULL_END
