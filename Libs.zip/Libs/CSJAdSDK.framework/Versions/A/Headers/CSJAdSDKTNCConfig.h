//
// Created by bytedance on 2020/12/16.
//

#import <Foundation/Foundation.h>

#define kBU_AD_TNC_APP_KEY @"BUAdSDK_CN"
