//
//  CSJFullScreenInterstitialCoverView.h
//  CSJAdSDK
//
//  Created by bytedance on 2021/1/9.
//

#import "CSJFullScreenInterstitialAdView.h"

NS_ASSUME_NONNULL_BEGIN

@interface CSJFullScreenInterstitialCoverView : CSJFullScreenInterstitialAdView

@end

NS_ASSUME_NONNULL_END
