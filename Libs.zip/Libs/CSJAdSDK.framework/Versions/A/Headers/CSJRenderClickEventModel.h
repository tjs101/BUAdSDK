//
//  CSJRenderClickEventModel.h
//  CSJAdSDK
//
//  Created by Rush.D.Xzj on 2021/2/9.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, BUAreaType) {
    // 以下几个枚举值是JS的，以后尽量不要用了。 1. 命名有问题  2. 枚举值缺少几个
    BUAreaTypeNone = 0, // js不会下发，这里是相当于默认值
    BUAreaTypeLandscape = 1,
    BUAreaTypeLandCreative = 2,
    BUAreaTypeLandDislike = 3,
    BUAreaTypeLandVideoDetail = 4,
    
    
        
    // 以下几个枚举值是JS的， 以后尽量使用下面的，上面的尽量不要用了
    BUAreaType_None = 0, //不可点击
    BUAreaType_Normal = 1, // 普通区域
    BUAreaType_Creative = 2, // 创意区域
    BUAreaType_Dislike = 3, // DISLIKE
    BUAreaType_Video = 4, // 视频区域
    BUAreaType_Playable = 5,
    BUAreaType_Video_Control = 99, // 视频控制播放/暂停
    BUAreaType_Privacy = -1, // 打开隐私协议, 用 openPrivacy jsb 方法，负值表示没有实际传递意义
    BUAreaType_Ignore = -2, // 某些情况下会有 hardcode 情况，需要忽略掉默认的点击事件。设置为此值将自行处理 areaType 响应。在统一处理处将会忽略
    
};
// 模板clickEvent点击的区域类型
// 4300链路优选需要判断点击的区域做相应的跳转逻辑
typedef NS_ENUM(NSInteger, BUExpressClickAreaCategory) {
    BUExpressClickAreaCategoryUnknow = -1,
    /// 视频区域
    BUExpressClickAreaCategoryVideo = 1,
    /// 图片区域
    BUExpressClickAreaCategoryImage = 2,
};

@interface CSJRenderClickEventModel : NSObject

// 默认值是BUAreaTypeNone
@property (nonatomic, assign) BUAreaType areaType;
@property (nonatomic, copy) NSString *clickAreaType;
@property (nonatomic, copy) NSDictionary *clickInfo;
@property (nonatomic, assign) BUAdUserBehaviorType userBehaviorType;
@property (nonatomic, assign) BUExpressClickAreaCategory clickAreaCategory;

- (id)initWithDictionary:(NSDictionary *)dictionary;

@end

NS_ASSUME_NONNULL_END
