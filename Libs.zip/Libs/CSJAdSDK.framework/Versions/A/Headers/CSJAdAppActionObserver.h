//
//  CSJAdAppActionObserver.h
//  CSJAdSDK
//
//  Created by Eason on 2021/1/14.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CSJAdAppActionObserver : NSObject
+ (instancetype)shareInstance;
@end

NS_ASSUME_NONNULL_END
