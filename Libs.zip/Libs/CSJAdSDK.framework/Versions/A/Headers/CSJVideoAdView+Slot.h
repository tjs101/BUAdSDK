//
//  CSJVideoAdView+Slot.h
//  CSJAdSDK
//
//  Created by cuiyanan on 2019/5/29.
//  Copyright © 2019 bytedance. All rights reserved.
//

#import "CSJVideoAdView.h"
#import "CSJAdSlot.h"

@interface CSJVideoAdView ()
@property (nonatomic, strong) CSJAdSlot *adslot;
@end

